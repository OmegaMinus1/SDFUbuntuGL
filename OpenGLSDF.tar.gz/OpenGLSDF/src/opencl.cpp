#include "opencl.h"

OpenCL::OpenCL(SDL_GLContext* glContext, SDL_Window* window)
{

}

OpenCL::~OpenCL()
{

}
